package model;

public interface Worker {
    float calcularNomina();
    float calcularIRPF();
}
