package model;

public abstract class User implements Comparable<User> {
    private String dni;
    private String nom;
    private String cognom1;
    private String cognom2;
    private String email;

    public User(String dni, String nom, String cognom1, String cognom2, String email) {
        this.dni = dni;
        this.nom = nom;
        this.cognom1 = cognom1;
        this.cognom2 = cognom2;
        this.email = email;
    }

    protected String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getCognom1() {
        return cognom1;
    }

    public void setCognom1(String cognom1) {
        this.cognom1 = cognom1;
    }

    public String getCognom2() {
        return cognom2;
    }

    public void setCognom2(String cognom2) {
        this.cognom2 = cognom2;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    /*
    cognom1 cognom2 nom

    0 si u i this són igual
    1 si this > u
    -1 si this < u
     */
    @Override
    public int compareTo(User u) {
        String u1 = this.getCognom1()+this.getCognom2()+this.getNom();
        String u2 = u.getCognom1()+u.getCognom2()+u.getNom();
        return u1.compareTo(u2);
    }


    @Override
    public String toString() {
        return "Usuari{" +
                "dni='" + dni + '\'' +
                ", nom='" + nom + '\'' +
                ", cognom1='" + cognom1 + '\'' +
                ", cognom2='" + cognom2 + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}
