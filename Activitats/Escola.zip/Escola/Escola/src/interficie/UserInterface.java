package interficie;

public interface UserInterface {
    void pintaMenu() throws Exception;
    void afegirUsuari() throws Exception;
    void llistarUsuaris();
}
